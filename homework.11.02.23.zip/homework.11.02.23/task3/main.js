document.body.addEventListener("keydown", (event) => { 
    document.getElementById("text").innerText = event.key.charCodeAt();
})


