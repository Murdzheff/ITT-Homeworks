let arr = [];

console.log(arr)

for (i = 0; i < 10; i++) {
    arr.push(i * 3);
};

console.log(arr);