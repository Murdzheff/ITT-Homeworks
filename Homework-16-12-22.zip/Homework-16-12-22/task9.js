let initialArr = [1,2,3];
let reversedArr = [];

for (i = initialArr.length - 1; i >= 0; i--) {
    reversedArr.push(initialArr[i]);
};
console.log(initialArr);
console.log(reversedArr);
