let n=5;
let result=1;
let i =0;

do{
    i+=1;
    result*=i
    
}while(i<n)

console.log(result);