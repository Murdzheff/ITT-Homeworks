for (i = 1; i <= 5; i++) {
    switch (i) {
        case 1:
            console.log("1   2   3   4   5");
            break;
        case 2:
            console.log("16  17  18  19  6");
            break;
        case 3:
            console.log("15  24  25  20  7");
        case 4:
            console.log("14  23  22  21  8");
            break;
        case 5:
            console.log("13  12  11  10  9");
    };
};