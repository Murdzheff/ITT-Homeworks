for (i = 1; i <= 5; i++) {
    switch (i) {
        case 1:
            console.log(12345);
            break;
        case 2:
            console.log(21234);
            break;
        case 3:
            console.log(32123);
            break;
        case 4:
            console.log(43212);
            break;
        case 5:
            console.log(54321);
            break;
    };
};