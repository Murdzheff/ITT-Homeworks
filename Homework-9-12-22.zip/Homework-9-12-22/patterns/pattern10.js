for (i = 1; i <= 5; i++) {
    let pattern = "";
    for (j = 1; j <= 5; j++) {
        pattern += i + 1 - 1; 
    };
    console.log(pattern);
};